void displayFraction( int a = 0, int b = 1 );

int gcd( int a, int b );

bool reduceFraction( int &num, int&denom );
