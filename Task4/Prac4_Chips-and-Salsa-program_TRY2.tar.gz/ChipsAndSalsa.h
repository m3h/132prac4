#include <string>
using namespace std;

const int NUM_OF_SALSA_TYPES = 6;

string salsaName[6] = { "mild", "medium", "sweet", "hot", "zesty", "SUPA hot" };

int numOfJars[6] = {};


